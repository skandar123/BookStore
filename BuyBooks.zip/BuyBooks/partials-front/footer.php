<!-- Footer for customer's login -->
<!-- Start of Social Section -->
<section class="social">
	<div class="container text-center">
		<ul>
			<li>
				<a href="#"><img src="https://img.icons8.com/fluent/50/000000/facebook-new.png"/></a>
			</li>
			<li>
				<a href="#"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png"/></a>
			</li>
			<li>
				<a href="#"><img src="https://img.icons8.com/fluent/48/000000/twitter.png"/></a>
			</li>
		</ul>
	</div>
</section>
<!-- End of Social Section -->

<!-- Start of Footer Section -->
<section class="footer">
	<div class="container text-center">
		<p>All rights reserved. Designed By Sayantika Kandar</p>
	</div>
</section>
<!-- End of Footer Section -->
</body>
</html>