<?php include('menu.php'); ?>
<section class="contact">
	<div class="container">
		<h2 class="text-center">Contact</h2>
		<div align="center">
		<img src="../images/books_pic.png" width="300" height="200"><br><br>
		<p><b>Address: </b>SK BookStore, Saraswati Road, Mumbai, Maharashtra, India<br>
		   <b>Hours of Operation: </b>9am-9pm<br>
		   <b>Phone: </b>+91 9123456789<br>
		   <b>Email: </b>info@skbookstore.com
		</p>
		</div>
	</div>  
</section>
<?php include('footer.php'); ?>