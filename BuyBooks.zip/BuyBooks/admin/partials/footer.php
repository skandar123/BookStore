<!-- Footer -->
		<div class="footer">
			<div class="wrapper">
				<p class="text-center">2022 All Rights Reserved. SK's Online BookStore. Developed by Sayantika Kandar</p>
			</div>
		</div>
	</body>
</html>